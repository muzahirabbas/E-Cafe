/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package lsb2.cafe;

import java.util.ArrayList;

/**
 *
 * @author Mushaf Ali
 */
public class listofdish {
    public ArrayList<dishes> list= new ArrayList();
    listofdish(){
    }
}
